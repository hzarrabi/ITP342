//
//  ViewController.h
//  Flashcard
//
//  Created by Yunzhi Yu on 10/16/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.







// use one free three day

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

