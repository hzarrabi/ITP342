//
//  NoteTool.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
#import <Foundation/Foundation.h>

@class NoteModel;

@interface NoteTool : NSObject

/**
 *  save Note
 */
+ (void)saveNote:(NoteModel *)note;

/**
 *  delete Note
 */
+ (void)removeNote:(NoteModel *)note;

/**
 *  retrieve notes from database
 */
+ (NSArray *)notes;

@end
