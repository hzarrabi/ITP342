//
//  NoteTool.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

// operation on FMDatatbase
#import "NoteTool.h"
#import "FMDB.h"
#import "NoteModel.h"

static FMDatabase *_db;

@implementation NoteTool

+ (void)initialize
{
    [super initialize];
    
    NSString *dbPath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"notes.db"];
    _db = [FMDatabase databaseWithPath:dbPath];
    [_db open];
    
    [_db executeUpdate:@"CREATE TABLE IF NOT EXISTS t_notes (id integer PRIMARY KEY, notes blob NOT NULL, note_id text NOT NULL);"];
}

+ (void)saveNote:(NoteModel *)note
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:note];
    [_db executeUpdateWithFormat:@"INSERT INTO t_notes (notes, note_id) VALUES (%@, %@);", data, note.date.description];
}

+ (void)removeNote:(NoteModel *)note
{
    [_db executeUpdateWithFormat:@"DELETE FROM t_notes WHERE note_id = %@;", note.date.description];
}

+ (NSArray *)notes
{
    FMResultSet *set = [_db executeQuery:@"SELECT * FROM t_notes ORDER BY id DESC;"];
    NSMutableArray *notes = [NSMutableArray array];
    while (set.next) {
        NSData *data = [set objectForColumnName:@"notes"];
        NoteModel *note = [NSKeyedUnarchiver unarchiveObjectWithData:data];
        [notes addObject:note];
    }
    
    return notes;
}

@end
