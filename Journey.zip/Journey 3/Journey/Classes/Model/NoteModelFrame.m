//
//  NoteModelFrame.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//


//calculate and adjust the size of the cell
#define NoteCellMargin 10
#define ScreenW [UIScreen mainScreen].bounds.size.width

#import "NoteModelFrame.h"
#import "NoteModel.h"
#import "NSString+Extension.h"

@implementation NoteModelFrame

+ (instancetype)noteFrameWithNote:(NoteModel *)note
{
    NoteModelFrame *noteF = [[NoteModelFrame alloc] init];
    noteF.note = note;
    return noteF;
}

- (void)setNote:(NoteModel *)note
{
    _note = note;
    
    CGFloat dateX = NoteCellBorder;
    CGFloat dateY = 0;
    CGFloat dateMaxW = ScreenW - 2 * NoteCellBorder;
    NSString *dateStr = [NSString stringFromDate:note.date];
    CGSize dateSize = [dateStr stringSizeWithFont:NoteCellContentFont maxWidth:dateMaxW];
    self.dateLabelF = (CGRect){{dateX, dateY}, dateSize};
    
    CGFloat textX = dateX;
    CGFloat textY = CGRectGetMaxY(self.dateLabelF) + NoteCellBorder;
    CGFloat maxW = ScreenW - 2 * NoteCellBorder;
    CGSize textSize = [note.text stringSizeWithFont:NoteCellContentFont maxWidth:maxW];
    self.textLabelF = (CGRect){{textX, textY}, textSize};
    
    CGFloat locationX = textX;
    CGFloat locationY = 0;
    if (note.image) {
        CGFloat imageX = textX;
        CGFloat imageY = CGRectGetMaxY(self.textLabelF) + NoteCellBorder;
        self.imageViewF = (CGRect){{imageX, imageY}, {ScreenW - 2 * NoteCellBorder, 300}};
        locationY = CGRectGetMaxY(self.imageViewF) + NoteCellBorder;
    } else {
        locationY = CGRectGetMaxY(self.textLabelF) + NoteCellBorder;
    }
    
    if (note.location) {
        CLLocationCoordinate2D coordinate2D = note.location.coordinate;
        NSString *locationStr = [NSString stringWithFormat:@"Location:(%f, %f)", coordinate2D.longitude, coordinate2D.latitude];
        CGSize locationStrSize = [locationStr stringSizeWithFont:NoteCellContentFont maxWidth:maxW];
        self.locationLabelF = (CGRect){{locationX, locationY}, locationStrSize};
    } else {
        self.locationLabelF = (CGRect){{locationX, locationY}, {0, 0}};
    }

    self.divideViewF = CGRectMake(0, CGRectGetMaxY(self.locationLabelF) + NoteCellBorder, ScreenW, 1);
    self.noteViewF = CGRectMake(0, NoteCellMargin, ScreenW, CGRectGetMaxY(self.divideViewF));
    self.cellH = CGRectGetMaxY(self.noteViewF);
}

@end
