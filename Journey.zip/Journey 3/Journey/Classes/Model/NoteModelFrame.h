//
//  NoteModelFrame.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define NoteCellBorder 8
#define NoteCellContentFont [UIFont systemFontOfSize:15]

@class NoteModel;

@interface NoteModelFrame : NSObject
/** Note Model */
@property (strong, nonatomic) NoteModel *note;

@property (nonatomic, assign) CGRect noteViewF;
@property (assign, nonatomic) CGRect dateLabelF;
@property (nonatomic, assign) CGRect textLabelF;
@property (nonatomic, assign) CGRect imageViewF;
@property (assign, nonatomic) CGRect locationLabelF;
@property (assign, nonatomic) CGRect divideViewF;
@property (nonatomic, assign) CGFloat cellH;

+ (instancetype)noteFrameWithNote:(NoteModel *)note;

@end
