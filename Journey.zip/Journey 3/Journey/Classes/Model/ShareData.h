//
//  ShareData.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"

@class NoteModel;

@interface ShareData : NSObject

SingletonH(ShareData)

- (void)addNewNote:(NoteModel *)note;
- (void)removeOldNoteWithRow:(NSInteger)row;
- (NSArray *)readAllNotes;

@end
