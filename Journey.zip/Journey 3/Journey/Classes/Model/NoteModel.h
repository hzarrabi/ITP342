//
//  NoteModel.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface NoteModel : NSObject <NSCoding>

/** 正文 */
@property (copy, nonatomic) NSString *text;
/** 图片 */
@property (strong, nonatomic) UIImage *image;
/** 日期 */
@property (strong, nonatomic) NSDate *date;
/** 定位 */
@property (strong, nonatomic) CLLocation *location;

- (instancetype)initWithText:(NSString *)text image:(UIImage *)image date:(NSDate *)date location:(CLLocation *)location;
+ (instancetype)noteWithText:(NSString *)text image:(UIImage *)image date:(NSDate *)date location:(CLLocation *)location;

@end
