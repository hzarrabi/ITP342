// .h
#define SingletonH(className) + (instancetype)share##className;

// .m
#ifdef __has_feature(objc_arc)

#define SingletonM(className) \
 \
static id _instance; \
 \
+ (instancetype)allocWithZone:(struct _NSZone *)zone { \
    static dispatch_once_t onceToken; \
    dispatch_once(&onceToken, ^{ \
        _instance = [super allocWithZone:zone]; \
    }); \
    return _instance; \
} \
 \
+ (instancetype)share##className { \
    static dispatch_once_t onceToken; \
    dispatch_once(&onceToken, ^{ \
        _instance = [[self alloc] init]; \
    }); \
    return _instance; \
} \
 \
- (id)copy { \
    return _instance; \
}

#else 

#define SingletonM(className) \
 \
static id _instance; \
 \
+ (instancetype)allocWithZone:(struct _NSZone *)zone { \
    static dispatch_once_t onceToken; \
    dispatch_once(&onceToken, ^{ \
        _instance = [super allocWithZone:zone]; \
    }); \
    return _instance; \
} \
 \
+ (instancetype)shareSingleton { \
    static dispatch_once_t onceToken; \
    dispatch_once(&onceToken, ^{ \
        _instance = [[self alloc] init]; \
    }); \
    return _instance; \
} \
 \
- (id)copy { \
    return _instance; \
} \
 \
- (oneway void)release { \
} \
 \
- (instancetype)autorelease { \
    return self; \
} \
 \
- (instancetype)retain { \
    return self; \
} \
 \
- (NSUInteger)retainCount { \
    return 1; \
}

#endif
