//
//  ShareData.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "ShareData.h"
#import "NoteTool.h"
#import "NoteModel.h"

@interface ShareData ()
@property (strong, nonatomic) NSMutableArray *notes;
@end

@implementation ShareData

SingletonM(ShareData)

- (NSMutableArray *)notes
{
    if (_notes == nil) {
        _notes = [[NSMutableArray alloc] initWithArray:[NoteTool notes]];
    }
    return _notes;
}

- (void)addNewNote:(NoteModel *)note
{
    [self.notes insertObject:note atIndex:0];
    [NoteTool saveNote:note];
}

- (void)removeOldNoteWithRow:(NSInteger)row
{
    NoteModel *note = self.notes[row];
    [NoteTool removeNote:note];
    [self.notes removeObjectAtIndex:row];
}

- (NSArray *)readAllNotes
{
    return self.notes;
}

@end
