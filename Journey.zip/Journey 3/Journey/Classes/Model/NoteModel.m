//
//  NoteModel.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "NoteModel.h"

@implementation NoteModel

- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:self.text forKey:@"text"];
    [encoder encodeObject:self.image forKey:@"image"];
    [encoder encodeObject:self.date forKey:@"date"];
    [encoder encodeObject:self.location forKey:@"location"];
}

- (instancetype)initWithCoder:(NSCoder *)decoder
{
    if (self = [super init]) {
        self.text = [decoder decodeObjectForKey:@"text"];
        self.image = [decoder decodeObjectForKey:@"image"];
        self.date = [decoder decodeObjectForKey:@"date"];
        self.location = [decoder decodeObjectForKey:@"location"];
    }
    return self;
}

- (instancetype)initWithText:(NSString *)text image:(UIImage *)image date:(NSDate *)date location:(CLLocation *)location
{
    self = [super init];
    if (self) {
        self.text = text;
        self.image = image;
        self.date = date;
        self.location = location;
    }
    return self;
}


+ (instancetype)noteWithText:(NSString *)text image:(UIImage *)image date:(NSDate *)date location:(CLLocation *)location
{
    return [[self alloc] initWithText:text image:image date:date location:location];
}

@end
