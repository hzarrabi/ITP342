//
//  NoteCellCollectionViewCell.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "NoteCell.h"
#import "NoteModel.h"
#import "NoteModelFrame.h"
#import "NSString+Extension.h"

@interface NoteCell ()

@property (nonatomic, weak) UIView *noteView;
@property (weak, nonatomic) UILabel *dateLabel;
@property (weak, nonatomic) UILabel *noteLabel;
@property (weak, nonatomic) UIImageView *noteImageView;
@property (weak, nonatomic) UILabel *locationLabel;
@property (weak, nonatomic) UIView *divideView;

@end

@implementation NoteCell

+ (instancetype)noteCellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"Note";
    NoteCell *cell =  [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[NoteCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIView *noteView = [[UIView alloc] init];
        [self.contentView addSubview:noteView];
        self.noteView = noteView;
        
        UILabel *dateLabel = [[UILabel alloc] init];
        dateLabel.font = NoteCellContentFont;
        [self.noteView addSubview:dateLabel];
        self.dateLabel = dateLabel;
        
        UILabel *noteLabel = [[UILabel alloc] init];
        noteLabel.font = NoteCellContentFont;
        noteLabel.numberOfLines = 0;
        [self.noteView addSubview:noteLabel];
        self.noteLabel = noteLabel;
        
        UIImageView *noteImageView = [[UIImageView alloc] init];
        [self.noteView addSubview:noteImageView];
        self.noteImageView = noteImageView;
        
        UILabel *locationLabel = [[UILabel alloc] init];
        locationLabel.font = NoteCellContentFont;
        [self.noteView addSubview:locationLabel];
        self.locationLabel = locationLabel;
        
        UIView *divideView = [[UIView alloc] init];
        divideView.backgroundColor = [UIColor lightGrayColor];
        [self.noteView addSubview:divideView];
        self.divideView = divideView;
    }
    return self;
}

- (void)setNoteF:(NoteModelFrame *)noteF
{
    _noteF = noteF;
    
    NoteModel *note = noteF.note;
    
    self.noteView.frame =noteF.noteViewF;
    
    self.dateLabel.text = [NSString stringFromDate:note.date];
    self.dateLabel.frame = noteF.dateLabelF;
    
    self.noteLabel.text = note.text;
    self.noteLabel.frame = noteF.textLabelF;
    
    if (note.image) {
        self.noteImageView.hidden = NO;
        self.noteImageView.image = note.image;
        self.noteImageView.frame = noteF.imageViewF;
    } else {
        self.noteImageView.hidden = YES;
    }
    
    if (note.location) {
        self.locationLabel.hidden = NO;
        CLLocationCoordinate2D coordinate2D = note.location.coordinate;
        NSString *locationStr = [NSString stringWithFormat:@"Location:(%f, %f)", coordinate2D.longitude, coordinate2D.latitude];
        self.locationLabel.text = locationStr;
        self.locationLabel.frame = noteF.locationLabelF;
    } else {
        self.locationLabel.hidden = YES;
    }
    
    self.divideView.frame = noteF.divideViewF;
}

@end
