//
//  TextView.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.//

#import "TextView.h"

@implementation TextView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self];
    }
    return self;
}

/**
 *  remove nofitication
 */
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/**
 *  text area change
 */
- (void)textDidChange {
    [self setNeedsDisplay];
}

/**
 *
 */
- (void)setPlaceholder:(NSString *)placeholder {
    _placeholder = [placeholder copy];
    
    [self setNeedsDisplay];
}


- (void)setPlaceholderColor:(UIColor *)placeholderColor {
    _placeholderColor = placeholderColor;
    
    [self setNeedsDisplay];
}


- (void)setText:(NSString *)text {
    [super setText:text];
    [self setNeedsDisplay];
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    [super setAttributedText:attributedText];
    [self setNeedsDisplay];
}

/**
 *  set font
 */
- (void)setFont:(UIFont *)font {
    [super setFont:font];
    [self setNeedsDisplay];
}

/**
 *  redraw
 */
- (void)drawRect:(CGRect)rect {
    if ([self hasText]) return;
    
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = self.font;
    attrs[NSForegroundColorAttributeName] = self.placeholderColor ? self.placeholderColor : [UIColor grayColor];
    
    // draw letter
    CGFloat textX = 5;
    CGFloat textY = 8;
    CGFloat textW = rect.size.width - 2 * textX;
    CGFloat textH = rect.size.height - 2 * textY;
    CGRect placeholserRect = CGRectMake(textX, textY, textW, textH);
    
    [self.placeholder drawInRect:placeholserRect withAttributes:attrs];
}

@end
