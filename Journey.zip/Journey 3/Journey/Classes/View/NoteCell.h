//
//  NoteCellCollectionViewCell.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NoteModelFrame;

@interface NoteCell : UITableViewCell

@property (strong, nonatomic) NoteModelFrame *noteF;

+ (instancetype)noteCellWithTableView:(UITableView *)tableView;

@end
