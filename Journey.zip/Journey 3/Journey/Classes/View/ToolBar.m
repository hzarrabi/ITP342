//
//  ToolBar.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "ToolBar.h"
#import "UIView+Extension.h"

@interface ToolBar ()

@property (nonatomic, strong) NSMutableArray *btns;

@property (nonatomic, weak) UIButton *cameraBtn;
@property (nonatomic, weak) UIButton *photoBtn;
@property (weak, nonatomic) UILabel *locLabel;
@property (nonatomic, weak) UISwitch *locSwitch;

@end

@implementation ToolBar

+ (instancetype)toolBar
{
    return [[self alloc] init];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor lightGrayColor];
        UIButton *cameraBtn = [[UIButton alloc] init];
        [cameraBtn addTarget:self action:@selector(openCamera) forControlEvents:UIControlEventTouchUpInside];
        [cameraBtn setTitle:@"Camera" forState:UIControlStateNormal];
        [self addSubview:cameraBtn];
        self.cameraBtn = cameraBtn;
        
        UIButton *photoBtn = [[UIButton alloc] init];
        [photoBtn addTarget:self action:@selector(openPhoto) forControlEvents:UIControlEventTouchUpInside];
        [photoBtn setTitle:@"Photo" forState:UIControlStateNormal];
        [self addSubview:photoBtn];
        self.photoBtn = photoBtn;
        
        UILabel *label = [[UILabel alloc] init];
        label.text = @"Location";
        [self addSubview:label];
        self.locLabel = label;
        
        UISwitch *locSwitch = [[UISwitch alloc] init];
        [locSwitch addTarget:self action:@selector(switchLocation) forControlEvents:UIControlEventValueChanged];
        locSwitch.on = NO;
        [self addSubview:locSwitch];
        self.locSwitch = locSwitch;
    }
    return self;
}

- (void)openCamera
{
    if ([self.delegate respondsToSelector:@selector(toolBar:didClickButtonWithType:)]) {
        [self.delegate toolBar:self didClickButtonWithType:ToolBarButtonTypeCamera];
    }
}

- (void)openPhoto
{
    if ([self.delegate respondsToSelector:@selector(toolBar:didClickButtonWithType:)]) {
        [self.delegate toolBar:self didClickButtonWithType:ToolBarButtonTypePhoto];
    }
}

- (void)switchLocation
{
    if ([self.delegate respondsToSelector:@selector(toolBar:didSwitchLocation:)]) {
        [self.delegate toolBar:self didSwitchLocation:self.locSwitch.isOn];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSUInteger count = self.subviews.count;
    CGFloat btnW = self.width / count;
    CGFloat btnH = self.height;
    for (int i = 0; i < count - 1; ++i) {
        UIView *view = self.subviews[i];
        view.x = i * btnW;
        view.y = 0;
        view.width = btnW;
        view.height = btnH;
    }
    
    self.locSwitch.centerX = self.width - btnW * 0.5;
    self.locSwitch.centerY = self.height * 0.5;
}

@end
