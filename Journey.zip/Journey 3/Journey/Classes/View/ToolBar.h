//
//  ToolBar.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

typedef enum {
    ToolBarButtonTypeCamera,
    ToolBarButtonTypePhoto,
} ToolBarButtonType;

#import <UIKit/UIKit.h>

@class ToolBar;

@protocol ToolbarDelegate <NSObject>
@required
- (void)toolBar:(ToolBar *)toolBar didClickButtonWithType:(ToolBarButtonType)type;
- (void)toolBar:(ToolBar *)toolBar didSwitchLocation:(BOOL)isOn;
@end

@interface ToolBar : UIView

@property (weak, nonatomic) id <ToolbarDelegate> delegate;

+ (instancetype)toolBar;

@end
