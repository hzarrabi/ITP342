//
//  NSString+Extension.m
//  Weibo
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "NSString+Extension.h"

@implementation NSString (Extension)

/**
 *  calculate the single line length base on the font
 */
- (CGSize)stringSizeWithFont:(UIFont *)font {
    return [self stringSizeWithFont:font maxWidth:MAXFLOAT];
}

/**
 *  calculate the multiple lines' width base on the font and maxwidth
 */
- (CGSize)stringSizeWithFont:(UIFont *)font maxWidth:(CGFloat)maxWidth {
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = font;
    CGSize size = CGSizeMake(maxWidth, MAXFLOAT);
    return [self boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

+ (NSString *)stringFromDate:(NSDate *)date
{
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"MMM/dd/yyyy";
    return [fmt stringFromDate:date];
}

@end
