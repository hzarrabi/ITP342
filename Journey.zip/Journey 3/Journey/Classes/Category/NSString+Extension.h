//
//  NSString+Extension.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Extension)

/**
 *  calculate the single line length base on the font
 */
- (CGSize)stringSizeWithFont:(UIFont *)font;

/**
 *  calculate the width base on the font and maxWidth
 */
- (CGSize)stringSizeWithFont:(UIFont *)font maxWidth:(CGFloat)maxWidth;

+ (NSString *)stringFromDate:(NSDate *)date;

@end
