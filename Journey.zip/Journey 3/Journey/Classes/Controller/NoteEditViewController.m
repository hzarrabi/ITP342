//
//  NoteEditViewController.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "NoteEditViewController.h"
#import "TextView.h"
#import "ToolBar.h"
#import "UIView+Extension.h"
#import "ShareData.h"
#import "NoteModel.h"

#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#define YZNotificationCenter [NSNotificationCenter defaultCenter]

@interface NoteEditViewController () <UITextViewDelegate, ToolbarDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, CLLocationManagerDelegate>

@property (weak, nonatomic) TextView *textView;
@property (weak, nonatomic) UIImageView *imageView;
@property (weak, nonatomic) ToolBar *toolBar;
@property (strong, nonatomic) CLLocationManager *locationMgr;
@property (strong, nonatomic) CLLocation *location;
@property (assign, nonatomic) BOOL isLocationOn;

@end

@implementation NoteEditViewController

#pragma mark - Lazy load
- (UIImageView *)imageView {
    if (_imageView == nil) {
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.backgroundColor = [UIColor redColor];
        imageView.width = ScreenW;
        imageView.height = 200;
        imageView.x = 0;
        imageView.y = ScreenH - self.toolBar.height - imageView.height;
        [self.view addSubview:imageView];
        _imageView = imageView;
    }
    return _imageView;
}

#pragma mark - Init
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.locationMgr = [[CLLocationManager alloc] init];
    self.locationMgr.delegate = self;
    self.locationMgr.desiredAccuracy = kCLLocationAccuracyBest;
    self.locationMgr.distanceFilter = 10.0;
    [self.locationMgr requestAlwaysAuthorization];
    [self.locationMgr startUpdatingLocation];
    
    // Item
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleDone target:self action:@selector(cancelJourney)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(saveJourney)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    self.navigationItem.title = @"Add a Journey";
    
    // TextView
    TextView *textView = [[TextView alloc] init];
    textView.alwaysBounceVertical = YES;
    textView.delegate = self;
    textView.frame = self.view.frame;
    textView.font = [UIFont systemFontOfSize:15];
    textView.placeholder = @"Write a new journey.";
    textView.width = ScreenW;
    textView.height = 300;
    [self.view addSubview:textView];
    self.textView = textView;
    
    //
    [YZNotificationCenter addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:textView];
    
    //
    [YZNotificationCenter addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    // ToolBar
    ToolBar *toolBar = [ToolBar toolBar];
    toolBar.delegate = self;
    toolBar.width = ScreenW;
    toolBar.height = 44;
    toolBar.y = ScreenH - toolBar.height;
    [self.view addSubview:toolBar];
    self.toolBar = toolBar;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    self.location = locations.firstObject;
//    CLLocationCoordinate2D coordinate2D = self.location.coordinate;
//    NSLog(@"longitude:%f, latitude:%f", coordinate2D.longitude, coordinate2D.latitude);
}

/**
 *
 */
- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    NSDictionary *userInfo = notification.userInfo;
    NSTimeInterval duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGRect keyboardF = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    [UIView animateWithDuration:duration animations:^{
        self.toolBar.y = keyboardF.origin.y - self.toolBar.height;
    }];
}

/**
 *
 */
- (void)textDidChange {
    self.navigationItem.rightBarButtonItem.enabled = [self.textView hasText];
}


#pragma mark - Item Action
- (void)cancelJourney {
    [self.view endEditing:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveJourney {
    NoteModel *note = [NoteModel noteWithText:self.textView.text image:self.imageView.image date:[NSDate date] location:(self.isLocationOn ? self.location : nil)];
    NSLog(@"------ready to save note: %@ %@ %@ %@", note.text, note.image, note.date, note.location);
    
    [[ShareData shareShareData] addNewNote:note];
    
    __weak typeof(self) weakSelf = self;
    if (self.block) {
        weakSelf.block();
    }
    
    [self.view endEditing:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - ToolbarDelegate
- (void)toolBar:(ToolBar *)toolBar didClickButtonWithType:(ToolBarButtonType)type
{
    switch (type) {
        case ToolBarButtonTypePhoto:
            [self openImagePickerControllerWithSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            break;
        case ToolBarButtonTypeCamera:
            [self openImagePickerControllerWithSourceType:UIImagePickerControllerSourceTypeCamera];
            break;
        default:
            break;
    }
}

- (void)toolBar:(ToolBar *)toolBar didSwitchLocation:(BOOL)isOn
{
    self.isLocationOn = isOn;
}

#pragma mark - Private Method

- (void)openImagePickerControllerWithSourceType:(UIImagePickerControllerSourceType)sourceType {
    if (![UIImagePickerController availableMediaTypesForSourceType:sourceType]) return;
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
    ipc.sourceType = sourceType;
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:nil];
}

#pragma mark - UITextViewDelegate

/**
 *  drag enable
 */
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.view endEditing:YES];
}


#pragma mark - UIImagePickerControllerDelegate

/**
 *  UIImagePickerController use the image after selection
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    self.imageView.image = image;
}

@end
