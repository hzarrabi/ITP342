//
//  DetailViewController.h
//  Journey
//
//  Created by Yunzhi Yu on 12/7/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NoteModelFrame;

@interface DetailViewController : UIViewController
@property (strong, nonatomic) NoteModelFrame *noteF;
@end
