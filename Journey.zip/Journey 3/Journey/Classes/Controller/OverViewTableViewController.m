//
//  OverViewTableViewController.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "OverViewTableViewController.h"
#import "DetailViewController.h"
#import "NoteModelFrame.h"
#import "NoteModel.h"
#import "NSString+Extension.h"
#import "NoteTool.h"
#import "ShareData.h"

@interface OverViewTableViewController ()<UITableViewDataSource, UITableViewDelegate>

@end

@implementation OverViewTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(edit)];
}

- (void)edit
{
    self.navigationItem.rightBarButtonItem.title = self.editing ? @"Edit" : @"Done";
    self.editing = !self.editing;
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *notes = [[ShareData shareShareData] readAllNotes];
    return notes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ID = @"OverTableViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    
    NSArray *notes = [[ShareData shareShareData] readAllNotes];
    NoteModel *note = notes[indexPath.row];
    cell.textLabel.text = [NSString stringFromDate:note.date];
    cell.detailTextLabel.text = note.text;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // delete from the memory and database
        [[ShareData shareShareData] removeOldNoteWithRow:indexPath.row];
        
        // update JourneyViewController
        if (self.block) {
            self.block();
        }
        
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *detailVc = [[DetailViewController alloc] init];
    NSArray *notes = [[ShareData shareShareData] readAllNotes];
    detailVc.noteF = [NoteModelFrame noteFrameWithNote:notes[indexPath.row]];
    
    [self.navigationController pushViewController:detailVc animated:YES];
}

@end
