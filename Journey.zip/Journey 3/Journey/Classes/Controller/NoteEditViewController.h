//
//  NoteEditViewController.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^needToRefreshData)();

typedef void(^CompletionHandler)(NSString *text, NSData *image);
typedef void(^OnCancel)();


@interface NoteEditViewController : UIViewController

@property (copy, nonatomic)  needToRefreshData block;

@property (copy, nonatomic) CompletionHandler completionHandler;
@property (copy, nonatomic) OnCancel onCancelHandler;

@end
