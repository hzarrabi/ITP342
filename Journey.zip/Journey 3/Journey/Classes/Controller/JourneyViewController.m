//
//  JourneyCollectionViewController.m
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "JourneyViewController.h"
#import "NoteCell.h"
#import "NoteModelFrame.h"
#import "NoteEditViewController.h"
#import "OverViewTableViewController.h"
#import "NoteTool.h"
#import "ShareData.h"

@interface JourneyViewController ()
@property (strong, nonatomic) NSMutableArray *noteFrames;
@end

@implementation JourneyViewController

- (NSMutableArray *)noteFrames
{
    if (_noteFrames == nil) {
        _noteFrames = [NSMutableArray array];
    }
    return _noteFrames;
}



- (void)viewDidLoad {
    [super viewDidLoad];

    // Init Item
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStyleDone target:self action:@selector(addJourney)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"View" style:UIBarButtonItemStyleDone target:self action:@selector(viewAllJourneyInTableView)];
    self.navigationItem.title = @"Journey";
    
    self.tableView.backgroundColor = [UIColor redColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    // Load notes from database
    NSArray *notes = [[ShareData shareShareData] readAllNotes];
    [self.noteFrames addObjectsFromArray:[self noteFramesWithNotes:notes]];
}

- (NSArray *)noteFramesWithNotes:(NSArray *)notes
{
    NSMutableArray *array = [NSMutableArray array];
    for (NoteModel *note in notes) {
        [array addObject:[NoteModelFrame noteFrameWithNote:note]];
    }
    return array;
}


- (void)addJourney {
    NoteEditViewController *editVc =  [[NoteEditViewController alloc] init];
    __weak typeof(self) weakSelf = self;
    editVc.block = ^(){

        [weakSelf.noteFrames removeAllObjects];
        NSArray *notes = [[ShareData shareShareData] readAllNotes];
        [weakSelf.noteFrames addObjectsFromArray:[weakSelf noteFramesWithNotes:notes]];
        [weakSelf.tableView reloadData];
    };
    
    UINavigationController *navVc = [[UINavigationController alloc] initWithRootViewController:editVc];
    [self.navigationController presentViewController:navVc animated:YES completion:nil];
}

- (void)viewAllJourneyInTableView {
    OverViewTableViewController *overVc = [[OverViewTableViewController alloc] init];
    
    __weak typeof(self) weakSelf = self;
    overVc.block = ^(){
        [weakSelf.noteFrames removeAllObjects];
        NSArray *notes = [[ShareData shareShareData] readAllNotes];
        [weakSelf.noteFrames addObjectsFromArray:[weakSelf noteFramesWithNotes:notes]];
        [weakSelf.tableView reloadData];
    };
    
    [self.navigationController pushViewController:overVc animated:nil];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.noteFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // 1. obtain cell
    NoteCell *cell = [NoteCell noteCellWithTableView:tableView];
    
    // 2. retrieve NoteModelFrame model，set up cell
    cell.noteF = self.noteFrames[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NoteModelFrame *noteF = self.noteFrames[indexPath.row];
    return noteF.cellH;
}


@end
