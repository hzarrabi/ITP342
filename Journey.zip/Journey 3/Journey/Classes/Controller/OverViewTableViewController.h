//
//  OverViewTableViewController.h
//  Journey
//
//  Created by Yunzhi Yu on 12/5/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^refreshBlock)();

@interface OverViewTableViewController : UITableViewController

@property (copy, nonatomic) refreshBlock block;

@end
