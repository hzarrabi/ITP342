//
//  DetailViewController.m
//  Journey
//
//  Created by Yunzhi Yu on 12/7/16.
//  Copyright © 2016 Yunzhi Yu. All rights reserved.
//

#import "DetailViewController.h"
#import "NoteModel.h"
#import <GoogleMaps/GoogleMaps.h>
#import "NoteCell.h"
#import "NoteModelFrame.h"
#import "UIView+Extension.h"

#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height

@interface DetailViewController ()
@property (weak, nonatomic) UIScrollView *scrollView;
@property (weak, nonatomic) NoteCell *noteView;
@property (weak, nonatomic) GMSMapView *mapView;
@end

@implementation DetailViewController

- (NoteCell *)noteView
{
    if (_noteView == nil) {
        NoteCell *noteView = [[NoteCell alloc] init];
        noteView.x = 0;
        noteView.y = 0;
        noteView.width = ScreenW;
        [self.scrollView addSubview:noteView];
        _noteView = noteView;
    }
    return _noteView;
}

- (UIScrollView *)scrollView
{
    if (_scrollView == nil) {
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [self.view addSubview:scrollView];
        _scrollView = scrollView;
    }
    return _scrollView;
}

- (GMSMapView *)mapView
{
    if (_mapView == nil) {
        GMSMapView *mapView = [[GMSMapView alloc] init];
        [self.scrollView addSubview:mapView];
        _mapView = mapView;
    }
    return _mapView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
}

// set the size of the note
- (void)setNoteF:(NoteModelFrame *)noteF
{
    _noteF = noteF;
    
    self.noteView.height = noteF.cellH;
    self.noteView.noteF = noteF;
    
    NoteModel *note = noteF.note;
    if (note.location) {
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithTarget:note.location.coordinate zoom:6];
        self.mapView.frame = CGRectMake(0, noteF.cellH, ScreenW, 300);
        self.mapView.camera = camera;
        self.mapView.myLocationEnabled = YES;
        
        GMSMarker *marker = [[GMSMarker alloc] init];
        marker.position = note.location.coordinate;
        marker.title = @"me";
        marker.snippet = @"there there";
        marker.map = self.mapView;
    }
    
    self.scrollView.contentSize = CGSizeMake(ScreenW, noteF.cellH + 300);
}

@end
